<?php if($this->session->flashdata('success')){?>
<div class="alert alert-success alert-dismissable">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<?php echo $this->session->flashdata('success'); ?> </div>
<?php } ?>
<?php if($this->session->flashdata('error')){?>
<div class="alert alert-danger alert-dismissable">
	<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<?php echo $this->session->flashdata('error'); ?> </div>
<?php } ?>
<style>
legend {
background-color: gray;
color: white;
padding: 5px 10px;
}
</style>
<span id="alertdiv_2">
	
</span>
<div class="card">
	<div class="card-body">
		<form class="form-horizontal" autocomplete="off" method="post" enctype="multipart/form-data" action="" id="admin-form">
			<div class="row">
				<div class="col-sm-12">
					<ul class="nav nav-pills nav-stacked setting-nnnav" role="tablist">
						<li class="nav-item">
							<a class="nav-link active show" href="#tab_sliders" data-toggle="tab" role="tab">
							<?= __('admin.theme_sliders') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#tab_sections" data-toggle="tab" role="tab">
							<?= __('admin.theme_sections') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link"  href="#tab_recommendation" data-toggle="tab" role="tab">
							<?= __('admin.theme_recommendation') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link"  href="#tab_home_content" data-toggle="tab" role="tab">
							<?= __('admin.theme_home_content') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link"  href="#tab_home_videos" data-toggle="tab" role="tab">
							<?= __('admin.theme_home_videos') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link"  href="#tab_page_pages" data-toggle="tab" role="tab">
							<?= __('admin.theme_page_pages') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="#tab_settings" data-toggle="tab" role="tab"  >
							<?= __('admin.theme_settings') ?></a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="<?php echo base_url(); ?>"target=_blank>
							<?= __('admin.view_site') ?></a>
						</li>
					</ul>
				</div>
			</div>
			<div class="col-sm-12">
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane p-3 active show" id="tab_sliders">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Slider</h4>
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_slider/')  ?>">Add New Slider</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Title</th>
													<th width="450">Description</th>
													<th>Image</th>
													<th>Link</th>
													<th>Button Text</th>
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_sliders)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No silders Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_sliders as $slider) { ?>
												<tr>
													<td><?= $slider->title ?></td>
													<td width="600px"><?= $slider->description ?></td>
													<td><img src="<?php echo base_url("assets/images/theme_images/".$slider->image) ?>" height="50" width="auto"></td>
													<td><?= $slider->link ?></td>
													<td><?= $slider->button_text ?></td>
													<td><?= ($slider->status == 1) ?
														'<lable class="badge badge-success">Active</lable>' :
														'<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_slider/'. $slider->slider_id) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm" href="<?= base_url('themes/theme_delete/'. $slider->slider_id) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_sections">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Section</h4>
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_section/')  ?>">Add New Section</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Title</th>
													<th>Description</th>
													<th>Image</th>
													<th>Link</th>
													<th>Button Text</th>
													<th>Position</th>
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_sections)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No Sections Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_sections as $key => $section) { ?>
												<tr>
													<td><?= $section->title ?></td>
													<td width="600"><?= $section->description ?></td>
													<td><img src="<?php echo base_url("assets/images/theme_images/".$section->image) ?>" height="50" width="auto"></td>
													<td><?= $section->link ?></td>
													<td><?= $section->button_text ?></td>
													<td><?= (($section->position == 1) ? "Left" : (($section->position == 2) ? "Right" : "center")) ?>
													</td>
													<td><?= ($section->status == 1) ?
														'<lable class="badge badge-success">Active</lable>' :
														'<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_section/'. $section->section_id) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm" href="<?= base_url('themes/delete_section/'. $section->section_id) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_recommendation">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Recommendations</h4>
									
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_recommendation/')  ?>">Add New Recommendation</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Title</th>
													<th>Occupation</th>
													<th>Description</th>
													<th>Image</th>
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_recommendation)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No Recommendation Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_recommendation as $key => $recommendation) { ?>
												<tr>
													<td><?= $recommendation->title ?></td>
													<td><?= $recommendation->occupation ?></td>
													<td width="600"><?= $recommendation->description ?></td>
													<td><img src="<?php echo base_url("assets/images/theme_images/".$recommendation->image) ?>" height="50" width="auto"></td>
													<td><?= ($recommendation->status == 1) ?
														'<lable class="badge badge-success">Active</lable>' :
														'<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_recommendation/'. $recommendation->recommendation_id ) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm" href="<?= base_url('themes/delete_recommendation/'. $recommendation->recommendation_id ) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_home_content">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Home Content</h4>
									
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_homecontent/')  ?>">Add Home Content</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Title</th>
													<th>Description</th>
													<th>Image</th>
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_homecontent)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No Content Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_homecontent as $key => $homecontent) { ?>
												<tr>
													<td><?= $homecontent->title ?></td>
													<td width="650"><?= $homecontent->description ?></td>
													<td><img src="<?php echo base_url("assets/images/theme_images/".$homecontent->image) ?>" height="50" width="auto"></td>
													<td><?= ($homecontent->status == 1) ?
														'<lable class="badge badge-success">Active</lable>' :
														'<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_homecontent/'. $homecontent->homecontent_id) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm" href="<?= base_url('themes/delete_homecontent/'. $homecontent->homecontent_id) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_home_videos">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Home Videos</h4>
									
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_video/')  ?>">Add New Video</a>
									</div>
								</div>
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Video Title</th>
													<th>Video Sub Title</th>
													<th>Video Link</th>
													<th>Watch video</th>
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_videos)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No Data Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_videos as $key => $video) { ?>
												<tr>
													<td><?= $video->video_title ?></td>
													<td><?= $video->video_sub_title ?></td>
													<td><?= $video->video_link ?>
													</td>
													<td>
														<a class="btn btn-info btn-sm" href="<?= $video->video_link ?>" target="_blank" role="button">Watch video</a>
													</td>
													<td>
														<?= ($video->status == 1) ?
														'<lable class="badge badge-success">Active</lable>' :
														'<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_video/'. $video->video_id) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm" href="<?= base_url('themes/delete_video/'. $video->video_id) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_page_pages">
						<div class="col-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Theme Pages</h4>
									<div class="pull-right">
										<a class="btn btn-primary" href="<?= base_url('themes/add_new_page/')  ?>">Add New Page</a>
									</div>
								</div>
								
								<div class="card-body">
									<div class="table-responsive">
										<table class="table-hover table-striped table">
											<thead>
												<tr>
													<th>Id</th>
													<th>Page Name</th>
													<th>Slug</th>
													<th>Top Banner Title</th>
													<th>Top Banner Sub Title</th>
													<th>Page Content Title</th>
													<!-- <th>Page Content</th> -->
													<th>Status</th>
													<th><?= __('admin.action')?></th>
												</tr>
											</thead>
											<tbody>
												<?php if(empty($theme_pages)){ ?>
												<tr>
													<td colspan="100%" class="text-center">No Page Available</td>
												</tr>
												<?php } ?>
												<?php foreach ($theme_pages as $key => $page) { ?>
												<tr class="deleterow-<?php echo $page->page_id ?>">
													<td><?= $page->page_id ?></td>
													<td><?= $page->page_name ?></td>
													<td><?= $page->slug ?></td>
													<td><?= $page->top_banner_title ?></td>
													<td><?= $page->top_banner_sub_title ?></td>
													<td><?= $page->page_content_title ?></td>
													<!-- <td width="550"><?= $page->page_content ?></td> -->
													<td>
														<?php if ($page->status ==1) { ?>
														<i class="fa fa-toggle-on" style="cursor: pointer;color: green;font-size: 35px;width:50px" onclick="change_page_status('<?= $page->page_id ?>');" id="page_status_active_<?= $page->page_id ?>"> 
														<?php } else{ ?>
															
														<i class="fa fa-toggle-off" style="cursor: pointer;color: red;font-size: 35px;width:50px" onclick="change_page_status('<?= $page->page_id ?>');" id="page_status_active_<?= $page->page_id ?>"> 

														<?php } ?>	
														<input type="hidden" name="page_status" id="page_status_<?= $page->page_id ?>" value="<?php echo $page->status;?>">
														</i>

														
													<?php // ($page->status == 1) ?
														// '<lable class="badge badge-success">Active</lable>' :
														// '<lable class="badge badge-blue-grey">Inactive</lable>' ?>
													</td>
													
													<td>
														<a class="btn btn-primary btn-sm" href="<?= base_url('themes/edit_page/'. $page->page_id) ?>"><i class="fa fa-edit"></i></a>
														<a class="btn confirm btn-danger btn-sm delete_page" data-id="<?= $page->page_id; ?>" data-href="<?= base_url('themes/delete_page/'. $page->page_id) ?>"><i class="fa fa-trash"></i></a>
													</td>
												</tr>
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div role="tabpanel" class="tab-pane p-3" id="tab_settings">
						<div class="col-md-12">
							<div class="card m-b-30">
								<div class="card-header">
									<h4 class="card-title pull-left">Theme Settings</h4>
								</div>
								<div class="card-body">
									<fieldset class="mt-3">
										<legend>Membership Section Title & Sub Title</legend>
										<div class="row">
											<?php foreach ($theme_settings as $settings) { $setting_id = $settings->settings_id; } ?>
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Top Title</label>
													<input type ="hidden" name= "settings_id" value ="<?php echo @$setting_id;?>" >
													<input name="membership_top_title" value="<?php echo $settings->membership_top_title; ?>" class="form-control" type="text">
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Sub Title</label>
													<input name="membership_sub_title" class="form-control" value="<?php echo $settings->membership_sub_title; ?>" type="text">
												</div>
											</div>
										</div>
									</fieldset>
									<fieldset class="mt-5">
										<legend>Contact us page</legend>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Top Title</label>
													<input name="contact_us_t_title" value="<?php echo $settings->contact_us_t_title; ?>" class="form-control" type="text">
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Sub Title</label>
													<input name="contact_us_slug_title" class="form-control" value="<?php echo $settings->contact_us_slug_title; ?>" type="text">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Full Address</label>
													<input name="contact_us_full_address" class="form-control" value="<?php echo $settings->contact_us_full_address; ?>" type="text">
												</div>
											</div>
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Phone Number</label>
													<input name="contact_us_phone" class="form-control" value="<?php echo $settings->contact_us_phone; ?>" type="text" maxlength="20">
													<small>Type the + symbol before the number</small>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<label class="control-label">Google Map Iframe</label>
													<textarea name="contact_us_iframe" class="form-control" type="text" rows=4><?php echo $settings->contact_us_iframe; ?></textarea>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">YouTube Link</label>
													<input placeholder="Link" name="youtube_link" id="link" class="form-control" value="<?php echo $settings->youtube_link; ?>" type="text">
													<span class="text-danger" id="linkError"></span>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Facebook Link</label>
													<input placeholder="Link" name="facebook_link" id="link" class="form-control" value="<?php echo $settings->facebook_link; ?>" type="text">
													<span class="text-danger" id="linkError"></span>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Twitter Link</label>
													<input placeholder="Link" name="twitter_link" id="link" class="form-control" value="<?php echo $settings->twitter_link; ?>" type="text">
													<span class="text-danger" id="linkError"></span>
												</div>
											</div>
											<div class="col-sm-3">
												<div class="form-group">
													<label class="control-label">Instagram Link</label>
													<input placeholder="Link" name="instegram_link" id="link" class="form-control" value="<?php echo $settings->instegram_link; ?>" type="text">
													<span class="text-danger" id="linkError"></span>
												</div>
											</div>
										</div>
									</fieldset>
									
									<fieldset class="mt-5">
										<legend>Footer Edit Section</legend>
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Footer About Title</label>
													<input name="footer_about_title" class="form-control" value="<?php echo $settings->footer_about_title; ?>" type="text">
												</div>
											</div>
											
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Footer About Text</label>
													
													<textarea name="footer_about_text" class="form-control" type="text"><?php echo $settings->footer_about_text; ?></textarea>
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Menu A Title</label>
													<input name="footer_menu_title_a" class="form-control" value="<?php echo $settings->footer_menu_title_a; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Menu B Title</label>
													<input name="footer_menu_title_b" class="form-control" value="<?php echo $settings->footer_menu_title_b; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Video Title</label>
													<input name="video_title" class="form-control" value="<?php echo $settings->video_title; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Video Sub Title</label>
													<input name="video_sub_title" class="form-control" value="<?php echo $settings->video_sub_title; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-12">
												<div class="form-group">
													<label class="control-label">Copyright</label>
													<input placeholder="Insert Your Copyright" name="copyright" class="form-control" value="<?php echo $settings->copyright; ?>" type="text">
												</div>
											</div>
										</div>
									</fieldset>
									<fieldset class="mt-5">
										<legend>Bottom Banner Settings</legend>
										<div class="row">
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Banner bottom title</label>
													<input placeholder="Banner bottom title" name="banner_bottom_title" class="form-control" value="<?php echo $settings->banner_bottom_title; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Banner bottom slug</label>
													<input placeholder="Banner bottom slug" name="banner_bottom_slug" class="form-control" value="<?php echo $settings->banner_bottom_slug; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Button Text</label>
													<input placeholder="Button Text" name="banner_button_text" class="form-control" value="<?php echo $settings->banner_button_text; ?>" type="text">
												</div>
											</div>
											<div class="col-sm-6">
												<div class="form-group">
													<label class="control-label">Link</label>
													<input placeholder="Link" name="banner_button_link" id="link" class="form-control" value="<?php echo $settings->banner_button_link; ?>" type="text">
													<span class="text-danger" id="linkError"></span>
												</div>
											</div>
										</div>
									</fieldset>

									<fieldset class="mt-5">
										<legend>Login & Registration & Terms</legend>
										<div class="row">
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Login Pgae - Text Area</label>
													<textarea name="login_content" rows="10" class="form-control" type="text"><?php echo $settings->login_content; ?></textarea>
													<small>Recommend max 1000 charters</small>
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Login Pgae - Background Image</label>
													
													<div>
														<div class="fileUpload btn btn-sm btn-primary">
															<span><?= __('admin.choose_file') ?></span>
															<input id="avatar_login" name="avatar_login" class="upload" type="file" >
														</div>
														
														<?php
														if($settings->login_img !=''){
														$avatar= '/assets/images/theme_images/'.$settings->login_img;
														}else{
														$avatar= 'assets/login/multiple_pages/img/bg-photo.jpg';
														}
														?>
														
														<img id="output_login"  src="<?php echo base_url().$avatar;?>" class="thumbnail" border="0" width="220px" />
														
													</div>
												</div>
											</div>

											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Registration Page - Text Area</label>
													<textarea name="reg_content" rows="10" value="" class="form-control" type="text"><?php echo $settings->reg_content; ?></textarea>
													<small>Recommend max 1000 charters</small>
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Registration Page - Background Image</label>
													
													<div>
														<div class="fileUpload btn btn-sm btn-primary">
															<span><?= __('admin.choose_file') ?></span>
															<input id="avatar_registration" name="avatar_registration" class="upload" type="file" >
														</div>
														
														<?php
														if($settings->reg_img !=''){
														$avatar= '/assets/images/theme_images/'.$settings->reg_img;
														}else{
														$avatar= 'assets/login/multiple_pages/img/bg-photo.jpg';
														}
														?>
														
														<img id="output_registration"  src="<?php echo base_url().$avatar;?>" class="thumbnail" border="0" width="220px" />
														
													</div>
												</div>
											</div>

											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Terms Page - Text Area</label>
													<textarea name="terms_content" rows="10" value="" class="form-control" type="text"><?php echo $settings->terms_content; ?></textarea>
												</div>
											</div>
											
											<div class="col-md-6">
												<div class="form-group">
													<label class="control-label">Terms Page - Background Image</label>
													
													<div>
														<div class="fileUpload btn btn-sm btn-primary">
															<span><?= __('admin.choose_file') ?></span>
															<input id="avatar_terms" name="avatar_terms" class="upload" type="file" >
														</div>
														
														<?php
														if($settings->terms_img !=''){
														$avatar= '/assets/images/theme_images/'.$settings->terms_img;
														}else{
														$avatar= 'assets/login/multiple_pages/img/bg-photo.jpg';
														}
														?>
														
														<img id="output_terms"  src="<?php echo base_url().$avatar;?>" class="thumbnail" border="0" width="220px" />
														
													</div>
												</div>
											</div>


										</div>
									</fieldset>
									<br>

									<br>
									<div class="row">
										<button type="button" class="btn btn-primary btn-submit-theme"> Submit </button>
										<span class="loading-submit"></span>
									</div>
								</div>
								
								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</form>
</div>
</div>
<script>
$(document).ready(function() {
// we will use single function for both images
function read_url(input,display_id) {
  if (input.files && input.files[0]) {
    var reader = new FileReader();
    reader.onload = function(e) {
      $('#'+display_id).attr('src', e.target.result);
    }
    
    reader.readAsDataURL(input.files[0]); // convert to base64 string
  }
}

$("#avatar_login").change(function() {
  read_url(this,'output_login');
});
$("#avatar_registration").change(function() {
  read_url(this,'output_registration');
});
$("#avatar_terms").change(function() {
  read_url(this,'output_terms');
});
//delete page function
$(".delete_page").click(function(e){
	e.preventDefault();
	var href = $(this).attr("data-href");
	var id = $(this).attr("data-id");
	$.ajax({
url: href,
type: "GET",
success: function (data)
{
	$(".deleterow-" + id).remove();
	var alert_div = '<div class="alert alert-success alert-dismissable" ><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'+
		'<span id="alert_msg_2">Item has been successfully deleted!</span></div>';
	// $(".alertdiv").removeClass("alert alert-danger alert-dismissable").addClass("alert alert-success alert-dismissable");
	$("#alertdiv_2").append(alert_div);
	$("#alertdiv_2").show();
	setTimeout( function(){
	$("#alertdiv_2").fadeOut();
	}  , 2000 );
}
});
});
//summernote editor
$('#summernote').summernote({
minHeight: 300,
toolbar: [
// [groupName, [list of button]]
['style', ['bold', 'italic', 'underline', 'clear']],
['font', ['strikethrough', 'superscript', 'subscript']],
['fontsize', ['fontsize']],
['color', ['color']],
['para', ['ul', 'ol', 'paragraph']],
['height', ['height']]
]
});
});
</script>
<script type="text/javascript">
$(".confirm").on('click',function(){
if(!confirm("Are your sure ?")) return false;
		return 1;
	})
</script>
<script type="text/javascript">
$('.setting-nnnav li a').on('shown.bs.tab', function(event){
var x = $(event.target).attr('href');
	$(".btn-submit").hide();
if(x != '#tab_sliders'){
	$(".btn-submit").show();
}
localStorage.setItem("last_pill", x);
});
$(document).on('ready',function() {
	var last_pill = localStorage.getItem("last_pill");
	if(last_pill){ $('[href="'+ last_pill +'"]').click() }
});
// this function is used for save theme setting
$(".btn-submit-theme").on('click',function(evt){
$("#linkError").empty();
$this = $("#admin-form");
$(".btn-submit").btn("loading");
$('.loading-submit').show();
var res = $('#link').val();
var result = res.match(/(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g);
if(result == null)
{
$("#linkError").append("Please enter valid link");
$(".btn-submit").btn("reset");
return false;
}
$this = $("#admin-form");
$(".btn-submit-theme").btn("loading");
$('.loading-submit').show();
evt.preventDefault();
var formData = new FormData($("#admin-form")[0]);
formData = formDataFilter(formData);
$.ajax({
url:'<?= base_url('themes/update_settings') ?>',
type:'POST',
dataType:'json',
cache:false,
contentType: false,
processData: false,
data:formData,
xhr: function (){
var jqXHR = null;
if ( window.ActiveXObject ){
jqXHR = new window.ActiveXObject( "Microsoft.XMLHTTP" );
}else {
jqXHR = new window.XMLHttpRequest();
}
jqXHR.upload.addEventListener( "progress", function ( evt ){
if ( evt.lengthComputable ){
var percentComplete = Math.round( (evt.loaded * 100) / evt.total );
$('.loading-submit').text(percentComplete + "% Loading");
}
}, false );
jqXHR.addEventListener( "progress", function ( evt ){
if ( evt.lengthComputable ){
var percentComplete = Math.round( (evt.loaded * 100) / evt.total );
$('.loading-submit').text("Save");
}
}, false );
return jqXHR;
},
complete:function(result){
$(".btn-submit-theme").btn("reset");
},
success:function(result){
$('.loading-submit').hide();
$this.find(".has-error").removeClass("has-error");
$this.find("span.text-danger").remove();
if(result['location']){
window.location = result['location'];
}
console.log(result['errors']);
if(result['errors']){
$.each(result['errors'], function(i,j){
$ele = $this.find('[name="'+ i +'"]');
if($ele){
$ele.parents(".form-group").addClass("has-error");
$ele.after("<span class='text-danger'>"+ j +"</span>");
}
});
}
},
})
return false;
});
$(".alert").fadeTo(2000, 500).slideUp(500, function(){
$(".alert").alert('close');
});
function change_page_status(id){
	var page_status = $('#page_status_'+id).val();
	if (page_status== 1) {
		var status = 0;
		var msg = "Page Inactive successfully";
	}else{
		var status = 1;
		var msg = "Page Active successfully";
	}
	// call ajax
	$.ajax({
	url: "<?= base_url('themes/update_page_status/')  ?>",
	type: "POST",
	dataType: "json",
	data: {id:id,status:status},
	success: function (data)
	{	
		if (page_status == 1) {
			$('#page_status_active_'+id).addClass('fa-toggle-off');
			$('#page_status_active_'+id).removeClass('fa-toggle-on');
			$('#page_status_active_'+id).css("color", "red");
			$('#page_status_'+id).val(0);
		}
		if (page_status == 0) {
			// its mean current status is active 
			$('#page_status_active_'+id).addClass('fa-toggle-on');
			$('#page_status_active_'+id).removeClass('fa-toggle-off');
			$('#page_status_active_'+id).css("color", "green");
			$('#page_status_'+id).val(1);
		}
	}
	});
	
	
}
</script>