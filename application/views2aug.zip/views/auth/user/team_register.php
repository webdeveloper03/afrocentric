    <div class="row">
               <div class="col-md-12 mt-5">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="card left-card card-bg-44">
                           <div class="card-body">
                              <div class="row">
                                <div class="col-md-4">
                                    <img src="assets/images/site/Dei4vQVCMyr5fAszw38PRamGjH7ISl9O.png" alt="LOGO" style="max-height: 50px;">
                                 </div>
                                 <div class="col-md-8">
                                    <h4 class="log-in">Hi, Who are you?</h4>
                                  </div>
                              </div>
                              <div class="row">
                               <div class="col-md-12">
                                 <div class="wrapper">
                                        <div class="parent" onclick="" style="width: 25%;">
                                      <div class="child bg-one">
                                        
                                      </div>
                                      <a href="#" class="a-link">A Designer</a>
                                    </div>
                                   

                                    <div class="parent" onclick="" style="width:25%">
                                      <div class="child bg-three">
                                        
                                      </div>
                                      <a href="#" class="a-link"> Model</a>
                                    </div>
                                    <div class="parent" onclick="" style="width:25%">
                                      <div class="child bg-two">
                                        
                                      </div>
                                      <a href="#" class="a-link">A Tailer</a>
                                    </div>
                               </div>
                                  </div>
                                  </div>
                              </div><br/>
                              <div class="row">
                                <div class="col-md-12">
                                  <a class="btn sign-btn" href = "<?=base_url();?>login">Sign In</a>
                                </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                 
               </div>