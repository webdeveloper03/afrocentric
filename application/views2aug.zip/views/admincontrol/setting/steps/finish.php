<div>
	<h4 class="text-center"><?= __('admin.congrats') ?></h4>

	<p class="text-center mt-5">New Version (<?= SCRIPT_VERSION ?>) has been installed successfully. <br> Thank you, and enjoy!</p>

	<div class="text-center">
		<a href="<?= base_url('/admincontrol/dashboard') ?>" class='btn btn-success mt-3 mb-4'><?= __('admin.goto_dashboard') ?></a>
	</div>
</div>
