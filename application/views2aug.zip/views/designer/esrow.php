       <?php 
              $login = $this->session->userdata("login");
               if(isset($login) && $login == "OK"){

               include("sidebar.php"); ?>


 <!-- hire -->
               <section>
                        <div class="container">
                             <div class="row">
                                <div class="col-md-12">
                                   <nav class="navbar navbar-expand-lg navbar-light bg-light">
                                      <a class="navbar-brand" href="#"><h1 class="Appor">My Escrow </h1></a>
                                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon"></span>
                                      </button>

                                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                        <form class="form-inline my-2 my-lg-0">
                                          <ul class="navbar-nav apoint-1">
                                          <li class="nav-item active">
                                            <a class="nav-link" href="#">Active</a>
                                          </li>
                                          <li class="nav-item active">
                                            <a class="nav-link" href="#">Pending</a>
                                          </li>
                                          <li class="nav-item active">
                                            <a class="nav-link disabled" href="#">Closed</a>
                                          </li>
                                        </ul>
                                        </form>
                                      </div>
                                    </nav>
                                </div>
                             </div> 
                             <div class="row">
                                <div class="col-md-8">
                                   <div class="row">
                                       <div class="col-md-6" style="border-bottom: solid 1px">
                                         <input type="text" name="search" placeholder="Search here" style="border: none;"><i class="fa fa-search"></i>
                                      </div>
                                      <div class="col-md-6">
                                         <select style="border:none;">
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                         </select>
                                      </div>
                                   </div>
                                   <div class="row">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <p>Bespoke Appointment with Fashion House</p>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                </div>
                                <div class="col-md-4">
                                         <img src="<?=base_url();?>assets/images/desig-2.png" class="desig-2">
                                         <h6 class="text-center">Bespoke Appointment with Fashion House</h6>
                                         <div class="row">
                                            <div class="col-md-6">
                                               <h6>Date</h6>
                                            </div>
                                            <div class="col-md-6">
                                               <p>Jan 2, 2020</p>
                                            </div>
                                         </div>
                                         <div class="row">
                                            <div class="col-md-6">
                                               <h6>Price</h6>
                                            </div>
                                            <div class="col-md-6">
                                               <p>N15,000</p>
                                            </div>
                                         </div>
                                         <div class="row">
                                            <div class="col-md-6">
                                               <h6>Comment</h6>
                                            </div>
                                            <div class="col-md-6">
                                               <p>Lorem ipsum dolor ist…..</p>
                                            </div>
                                         </div>
                                         <div class="row">
                                            <div class="col-md-6">
                                               <h6>Status</h6>
                                               <p class="mt-5">Amount in Escrow</p>
                                            </div>
                                            <div class="col-md-6">
                                               <p>Pending</p>
                                               <p class="mt-5">N7,500</p>
                                            </div>
                                         </div>
                                        
                                  
                             </div>
                          </div>
                        </div>
               </section>
               <!-- hire -->




                             <!-- explore --><?php 
               }else{
   header("Location:".base_url()."login");
}?>