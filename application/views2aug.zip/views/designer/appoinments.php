       <?php 
              $login = $this->session->userdata("login");
               if(isset($login) && $login == "OK"){

               include("sidebar.php"); ?>


 <!-- hire -->
               <section>
                        <div class="container">
                             <div class="row">
                                <div class="col-md-12">
                                   <nav class="navbar navbar-expand-lg navbar-light bg-light">
                                      <a class="navbar-brand" href="#"><h1 class="Appor">My Appointments</h1></a>
                                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                        <span class="navbar-toggler-icon"></span>
                                      </button>

                                      <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                        <form class="form-inline my-2 my-lg-0">
                                          <ul class="navbar-nav apoint-1">
                                          <li class="nav-item active">
                                            <a class="nav-link" href="#">Active</a>
                                          </li>
                                          <li class="nav-item active">
                                            <a class="nav-link" href="#">Pending</a>
                                          </li>
                                          <li class="nav-item active">
                                            <a class="nav-link disabled" href="#">Closed</a>
                                          </li>
                                        </ul>
                                        </form>
                                      </div>
                                    </nav>
                                </div>
                             </div> 
                             <div class="row">
                                <div class="col-md-8">
                                   <div class="row">
                                       <div class="col-md-6" style="border-bottom: solid 1px">
                                         <input type="text" name="search" placeholder="Search here" style="border: none;"><i class="fa fa-search"></i>
                                      </div>
                                      <div class="col-md-6">
                                         <select style="border:none;">
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                             <option>
                                                Newest First
                                             </option>
                                         </select>
                                      </div>
                                   </div>
                                   <div class="row">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                    <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                     <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-6 mt-2">
                                         <h6>Bespoke Appointment with Fashion House</h6>
                                      </div>
                                      <div class="colmd-4">
                                         <h6>Jan 2, 2020<br/>16:00</h6>
                                      </div>
                                   </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="row mt-2">
                                      <div class="col-md-2">
                                         <img src="<?=base_url();?>assets/images/desig-1.png">
                                      </div>
                                      <div class="col-md-10 mt-3">
                                         <p>Bespoke Appointment with Fashion House</p>
                                      </div>
                                   </div> 
                                    <div class="row">
                                            <div class="col-md-4">
                                               <button class="btn btn-warning adj-1">Adjust Appointment</button>
                                            </div>
                                             <div class="col-md-4">
                                               <button class="btn btn-warning adj-2">Chat with Designer</button>
                                            </div>
                                             <div class="col-md-4">
                                               <button class="btn btn-warning adj-3">Cancel Appointment</button>
                                            </div>
                                         </div>
                                         <div class="row">
                                             <div class="col-md-12">
                                                <h6 class="text-center">View Details</h6>
                                             </div>
                                         </div>
                                         <div class="row">
                                             <div class="col-md-12">
                                                <div class="card-1">
                                                   <p>
                                                      Hello Emeka, I am in need of a skilled tailor. Are you down for a gig?
                                                   </p>
                                                   <p class="card-1-pe2">
                                                      12:00<br/> Today
                                                   </p>
                                                </div>
                                             </div>
                                          </div><br/>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="card-2">
                                                   <p>
                                                      Hello Emeka, I am in need of a skilled tailor. Are you down for a gig?
                                                   </p>
                                                   <p class="card-1-pe2">
                                                      12:00<br/> Today
                                                   </p>
                                                </div>
                                             </div>
                                          </div><br/>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="card-1">
                                                   <p>
                                                      Hello Emeka, I am in need of a skilled tailor. Are you down for a gig?
                                                   </p>
                                                   <p class="card-1-pe2">
                                                      12:00<br/> Today
                                                   </p>
                                                </div>
                                             </div>
                                          </div><br/>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <div class="card-2">
                                                   <p>
                                                      Hello Emeka, I am in need of a skilled tailor. Are you down for a gig?
                                                   </p>
                                                   <p class="card-1-pe2">
                                                      12:00<br/> Today
                                                   </p>
                                                </div>
                                             </div>
                                          </div> 
                                          <div class="row">
                                                <div class="col-md-10 mt-2">
                                                   <textarea class="form-control" placeholder="Type a message"></textarea>
                                                </div>
                                                <div class="col-md-2">
                                                   <button class="btn btn-default mt-3">Send</button>
                                                </div>
                                          </div>
                                </div>
                          </div>
                     </div>
               </section>
               <!-- hire -->




                             <!-- explore --><?php 
               }else{
   header("Location:".base_url()."login");
}?>