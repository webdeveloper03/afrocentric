               <!-- ==================
                  115 PAGE START
                  ================== -->
<style>
    .auth-wrapper{
        width:100 !important;
        padding:0px !important;
    }
    .plan-arrow {
         color: #000 !important;
    }   
</style>
                <section class="bg-white pb-5 ">
                  <div class="container-fluid sign-2-cnt-fluid">
                    <div class="row justify-content-between">
                      <div class="col-3">
                        <img src="<?=base_url();?>assets/images/site/Dei4vQVCMyr5fAszw38PRamGjH7ISl9O.png" id="logo" class="img-fluid sign2-imglogo">
                      </div>
                      <div class="col-3 text-right">
                        <button class="btn sign-btntop">
                          Sign In
                        </button>
                      </div>
                    </div>
                  </div>
                  <div class="container container-progress-2">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="col-10 col-md-6  mx-auto d-flex align-items-center justify-content-between">
                          <!-- <div class="number-circle number-active d-flex align-items-center justify-content-center font-weight-bold"> <i class="fa fa-check"></i> </div> -->
                          <div class="line-bar line-bar-active"></div>
                          <span class="prog-sp-1">Basic Information</span>
                          <!--div class="number-circle d-flex align-items-center justify-content-center font-weight-bold">2</div-->
                          <div class="line-bar"></div>
                          <span class="prog-sp-2">Categories</span>
                          <!-- <div class="number-circle d-flex align-items-center justify-content-center font-weight-bold">3</div> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container sign-2-container">
                    <div class="row first-row-sign2">
                      <div class="col-md-12">
                        <h2 class="sign-head">Tell us about you</h2>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <div class="div-icones text-center">
                          <a href="#">
                            <i class="fas fa-user icone-1"></i>
                            <i class="fas fa-plus icone2"></i>
                          </a>
                          
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12">
                        <form>
                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label class="web-label" for="exampleInputEmail1">House Address</label>
                                <input type="email" class="form-control sign2-f-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="web-label" for="exampleFormControlSelect1">City*</label>
                                <select class="form-control sign2-f-control" id="exampleFormControlSelect1">
                                  <option></option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-md-6">
                              <div class="form-group">
                                <label class="web-label" for="exampleFormControlSelect1">State*</label>
                                <select class="form-control sign2-f-control" id="exampleFormControlSelect1">
                                  <option></option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label class="web-label" for="exampleFormControlSelect1">Country/Region*</label>
                                <select class="form-control sign2-f-control" id="exampleFormControlSelect1">
                                  <option></option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <div class="form-group">
                                <label class="web-label" for="exampleInputEmail1">Phone Number*</label>
                                <input type="email" class="form-control sign2-f-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <div class="div-for-sex-label">
                                <label class="web-label" for="exampleInputEmail1">Sex*</label>
                              </div>
                              <div class="funkyradio">
                                <div class="funkyradio-danger">
                                  <input type="radio" name="radio" id="radio4" />
                                  <label for="radio4">Male</label>
                                </div>
                                <div class="funkyradio-warning">
                                  <input type="radio" name="radio" id="radio5" />
                                  <label for="radio5">Female</label>
                                </div>
                                <div class="funkyradio-info">
                                <input type="radio" name="radio" id="radio6" />
                                <label for="radio6">Other sexualities</label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-12">
                              <label class="web-label web-label-birth signlabel" for="exampleInputEmail1">Birthday</label>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-3">
                              <div class="form-group">
                                <select class="form-control sign2-f-control" id="exampleFormControlSelect1">
                                  <option>03</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                </select>
                              </div>
                            </div>
                            <div class="col-3">
                              <div class="form-group">
                                <select class="form-control sign2-f-control" id="exampleFormControlSelect1">
                                  <option>Sept</option>
                                  <option>2</option>
                                  <option>3</option>
                                  <option>4</option>
                                  <option>5</option>
                                </select>
                              </div>
                            </div>
                          </div>
                          <div class="row sign2-lastrow">
                            <div class="col-md-12">
                              <div class="div-for-sex-label mb-2">
                                <label class="web-label" for="exampleInputEmail1">Make profile public?</label>
                              </div>
                              <div class="funkyradio">
                                <div class="funkyradio-primary">
                                  <input type="radio" name="radio" id="radio2" checked/>
                                  <label for="radio2">Yes, I'll like to be public</label>
                                </div>
                                <div class="funkyradio-success">
                                  <input type="radio" name="radio" id="radio3" />
                                  <label for="radio3">No, I prefer to be private</label>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="row">
                            <div class="col-md-11 m-auto">
                              <button class="btn big-btn">
                                Continue
                              </button>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </section>

               <!-- ==================
                  115 PAGE ENDS
               ================== -->
