 <section class = "fixed-left bg-white">
                        <div class="container-fluid">
                           <div class="row">
                              <div class="col-md-12">
                                 <h3><img src="<?=base_url();?>assets/images/lgo-22-removebg-preview.png" class="logo-business"><span class="afro-a">AFROCENTRIC</span></h3>
                              </div>
                           </div>
                           <div class="row">
                              <div class="col-md-12">
                                 <div class="progress progress-striped active">
                                    <div class="bar" style="    width: 100%;background: #f0ae2a;"></div>

                                </div>
                                <div class="row">
                                 <div class="col-md-4"></div>
                                    <div class="col-md-3 float-left">
                                       Basic Information
                                    </div>
                                    <div class="col-md-3 float-right">
                                      <b> Basic Information</b>   
                                    </div>
                                    <div class="col-md-2"></div>
                                 </div>
                              </div>
                           </div>
                            <form  style="padding: 1% 1%;
    border: 1px solid #D4D4D4;
    margin: 2% 22%;">
                              <div class="row">
                                <div class="col-md-12">
                                    <h3 class="get-1">Tell us about your Business</h3>
                                </div>  
                              </div>
                              <div class="row">
                                    <div class="col-sm-12">
                                      
                                          <label class="label-1">
                                             <h6>Business Name*</h6>
                                                <p class="label-txt">John</p>
                                                   <input type="text" class="input">
                                                      <div class="line-box">
                                                         <div class="line"></div>
                                                      </div>
                                          </label>
                                         <label class="label-1">
                                          <h6>Business Type</h6>
                                          <p class="label-txt">Fashion Designer</p>
                                          <div class="row">
                                             <div class="col-md-12">
                                                <select class="form-control mt-5"style="border: none;border-bottom: solid 1px;">
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                </select>
                                                 <div class="line"></div>
                                             </div>
                                           </div>
                                           <div class="row">  
                                             <div class="col-md-12">
                                                <h6>Identification</h6>
                                                <p class="label-txt">Select One</p>
                                                <select class="form-control mt-5"style="border: none;border-bottom: solid 1px;">
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                </select>
                                                 <div class="line"></div>
                                             </div>
                                          </div>
                                         </label>
                                         <label class="label-1">
                                          <h6>National ID Number</h6>
                                           <p class="label-txt">National ID Number</p>
                                          <input type="text" class="input">
                                           <div class="line-box">
                                             <div class="line"></div>
                                           </div>
                                         </label>
                                            <label class="label-1">
                                             <h6>Years of Experience</h6>
                                              <p class="label-txt">5</p>
                                              <input type="text" class="input">
                                              <div class="line-box">
                                                <div class="line"></div>
                                              </div>
                                           </label> 
                                           <div class="row">  
                                             <div class="col-md-12">
                                                <h6>Education</h6>
                                                <p class="label-txt">Fashion School</p>
                                                <select class="form-control mt-5" style="border: none;border-bottom: solid 1px;">
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                   <option>1 - January - 2020</option>
                                                </select>
                                                 <div class="line"></div>
                                             </div>
                                          </div>
                                          <div class="row mt-5">
                                             <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                          </div>
                                          <div class="row mt-5">
                                             <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                              <div class="col-md-2">
                                               <h6 class="h6-checkbox"> <input type="checkbox" name="checkbox"> Bespoke</h6>
                                             </div>
                                          </div>
                                          </form>
                                    </div>      
               </section>
               <section>
                   <div class="container">
               			<div class="row">
                            <div class="col-md-6">
                                <button class="perview-1">Previous</button>
                            </div>
                            <div class="col-md-6">
                               <button class="perview-2">Continue</button>
                            </div>
                        </div>
               		</div>
               </section>