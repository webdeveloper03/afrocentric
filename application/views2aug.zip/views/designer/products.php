       <?php 
              $login = $this->session->userdata("login");
               if(isset($login) && $login == "OK"){

               include("sidebar.php"); ?>



<!-- explore -->
               <section>
                     <div class="container-fluid">
                           <div class="row">
                              <div class="col-md-2">
                                       <a href="<?=base_url()?>member/designer/step1" class="btn btn-primary  c-title-btn">Add New Product</a>
                                    
                              </div>
                                <div class="col-md-10">
                                   <ul class="nav nav-tabs" role="tablist" id="nav-tal">
                                     <li class="nav-item">
                                       <a class="nav-link active2 text-t" data-toggle="tab" href="#home"><b> All Products</b></a>
                                     </li>
                                     <li class="nav-item">
                                       <a class="nav-link text" data-toggle="tab" href="#menu2"><b>Deleted Products</b></a>
                                     </li>
                                   </ul>
                                </div>
                             </div>
                             <div class="row mt-5">
                                 <div class="col-md-8">
                                    
                                 </div>

                                <div class="col-md-3 search33">
                                   <input type="text" name="search" placeholder="Search here" class="search3"><i class="fa fa-search float-right"></i>
                                </div>
                             </div>
                             <div class="row mt-5">
                               <div class="col-md-12">
                                   <div class="row">
                                      <div class="col-md-2">
                                   <select class="select-1 s-1">
                                      <option>
                                         Size
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                   </select>
                                </div>
                                 <div class="col-md-2">
                                   <select class="select-1 s-2">
                                      <option>
                                         Color
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                   </select>
                                </div>
                                
                                 <div class="col-md-2">
                                   <select class="select-1 s-3">
                                      <option>
                                         Price
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                   </select>
                                </div>
                                
                                 <div class="col-md-2">
                                   <select class="select-1 s-4">
                                      <option>
                                         Ratings
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                      <option>
                                         Sort By: Newest First
                                      </option>
                                   </select>
                                </div>
                                   <div class="col-md-4">
                                       <select class="form-control select-2">
                                           <option value="volvo">Sort By</option>
                                           <option value="saab">Saab</option>
                                           <option value="mercedes">Mercedes</option>
                                           <option value="audi">Audi</option>
                                       </select>
                                 </div>
                              </div>
                           </div>
                        </div>
                             <div class="row mt-5">
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-22.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-23.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-24.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                             </div>
                             <div class="row mt-5">
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-25.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-26.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                 <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-27.png" alt="Card image cap">
                                      <div class="card-body">
                                        <p class="card-title emeta">Ready To Wear Kids top Complete Set</p>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                               <p> <img src="<?=base_url();?>assets/images/card67.png" class="w-10">John Doe</p>
                                               
                                             </div>
                                             <div class="col-md-6">
                                                 <div class="rate">
                                                       <input type="radio" id="star5" name="rate" value="5" />
                                                       <label for="star5" title="text">5 stars</label>
                                                       <input type="radio" id="star4" name="rate" value="4" />
                                                       <label for="star4" title="text">4 stars</label>
                                                       <input type="radio" id="star3" name="rate" value="3" />
                                                       <label for="star3" title="text">3 stars</label>
                                                       <input type="radio" id="star2" name="rate" value="2" />
                                                       <label for="star2" title="text">2 stars</label>
                                                       <input type="radio" id="star1" name="rate" value="1" />
                                                       <label for="star1" title="text">1 star</label>
                                                     </div>

                                             </div>

                                           </div>
                                           <div class="row">
                                              <div class="col-md-6">
                                                 <img src="<?=base_url();?>assets/images/rating2.png" class="w-100">
                                              </div>
                                              <div class="col-md-6">
                                                 <h4 class="emeta float-right">N15,000</h4>
                                              </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn2">SHOP NOW</a>
                                      </div>
                                    </div>
                                </div>
                             </div>
                          </div>
                        </div>
                        
               </section>
               <!-- explore -->



                             <!-- explore --><?php 
               }else{
   header("Location:".base_url()."login");
}?>