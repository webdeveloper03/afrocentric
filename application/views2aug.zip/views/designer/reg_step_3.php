<style>
    .auth-wrapper{
        width:100 !important;
        padding:0px !important;
    }
    .sign-head, .p-top-onesixteenpage{
        color:#222224;
    }
</style>
                <section class="bg-white pb-5">
                  <div class="container-fluid sign-2-cnt-fluid">
                    <div class="row justify-content-between">
                      <div class="col-3">
                        <img src="<?=base_url();?>assets/images/site/Dei4vQVCMyr5fAszw38PRamGjH7ISl9O.png" id="logo" class="img-fluid sign2-imglogo">
                      </div>
                      <div class="col-3 text-right">
                        <button class="btn sign-btntop">
                          Sign In
                        </button>
                      </div>
                    </div>
                  </div>
                  <div class="container container-progress-2">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="col-10 col-md-6  mx-auto d-flex align-items-center justify-content-between">
                          <!-- <div class="number-circle number-active d-flex align-items-center justify-content-center font-weight-bold"> <i class="fa fa-check"></i> </div> -->
                          <div class="line-bar line-bar-active"></div>
                          <span class="prog-sp-1 prog-sp-safa-1">Basic Information</span>
                          <!--div class="number-circle d-flex align-items-center justify-content-center font-weight-bold">2</div-->
                          <div class="line-bar line-bar-second-class"></div>
                          <span class="prog-sp-2 prog-sp-safa-2">Categories</span>
                          <!-- <div class="number-circle d-flex align-items-center justify-content-center font-weight-bold">3</div> -->
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container sign-2-container">
                    <div class="row first-row-sign2 first-row-sign2-2">
                      <div class="col-md-12">
                        <h2 class="sign-head">Let us know what you like</h2>
                        <p class="p-top-onesixteenpage">
                          This will help us streamline suggestions and posts for you. You can select multiple options.
                        </p>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-12" style="position: relative;">
                        <div class="circles-parent-div">
                          <p class="p-child-one">Ankara</p>
                          <p class="p-child-two">Fabrics</p>
                          <p class="p-child-three">Models</p>
                          <p class="p-child-four">Bespoke</p>
                          <p class="p-child-five">Ready To Wear</p>
                          <p class="p-child-six">Blogs</p>
                          <p class="p-child-seven">Children Outfits</p>
                          <p class="p-child-eight">Tailors</p>
                          <p class="p-child-nine">Designers</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="container sign2-container">
                    <div class="row mt-5 mb-5">
                      <div class="col-md-5">
                        <button class="btn sign2-btntop1">
                          Previous
                        </button>
                      </div>
                      <div class="col-md-2"></div>
                      <div class="col-md-5">
                        <button class="btn sign2-btntop2">
                          Continue
                        </button>
                      </div>
                    </div>
                  </div>
                </section>

               <!-- ==================
                  115 PAGE ENDS
               ================== -->