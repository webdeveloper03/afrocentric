       <?php 
              $login = $this->session->userdata("login");
               if(isset($login) && $login == "OK"){

               include("sidebar.php"); ?>




            <section>
                     <div class="container-fluid">
                           <div class="row nav-tal-2">
                                <div class="col-md-12">
                                   <ul class="nav nav-tabs-2" role="tablist" id="nav-tal">
                                     <li class="nav-item">
                                       <a class="nav-link active2 text-t" data-toggle="tab" href="#menu1">E-Magazine</a>
                                     </li>
                                     <li class="nav-item">
                                       <a class="nav-link text" data-toggle="tab" href="#menu2">Fashion News</a>
                                     </li>
                                     <li class="nav-item">
                                       <a class="nav-link text" data-toggle="tab" href="#menu3">Fashion Dictionary</a>
                                     </li>
                                   </ul>
                                </div>
                             </div>

                          <!-- Tab panes -->
                          <div class="tab-content">
                            <div id="menu1" class="container tab-pane active">
                             <div class="row mt-5">
                                 <div class="col-md-4">
                                   <div class="card card-img">
                                    <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body card-b">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                                    <div class="col-md-4">
                                   <div class="card card-img">
                                    <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body card-b">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                                   <div class="col-md-4">
                                   <div class="card card-img">
                                    <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body card-b">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                             </div>
                             <div class="row mt-5">
                                    <div class="col-md-4">
                                   <div class="card card-img">
                                    <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body card-b">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                                    <div class="col-md-4">
                                   <div class="card card-img">
                                     <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body card-b">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                                    <div class="col-md-4">
                                   <div class="card card-img">
                                    <h6 class="date-card">July 1</h6>
                                      <img class="card-img-top img-blog-1" src="<?=base_url()?>assets/images/thumbs_b_c_89c55b473340221b80db2d1ab4c2ac89.jpg" alt="Card image cap">
                                      <div class="card-body">
                                        <h6 class="card-title b-t-bold">
                                           CHALLENGES AND OPPORTUNITIES IN THE AFRICAN FASHION INDUSTRY
                                        </h6>
                                        <p class="blog-p">
                                           As a loyal platinum shopper of Macy's Store, my desire has always been to have..
                                        </p>
                                         <div class="row mt-3">
                                             <div class="col-md-12">
                                                <p class="b-t-bold"><i class="fas fa-bookmark book-m"></i>
                                                 &nbsp;E-Magazine</p>
                                             </div>
                                           </div>
                                      </div>
                                    </div>
                                </div>
                             </div>
                            </div>
                          </div>
                        </div>
               </section>
                             <!-- explore --><?php 
               }else{
   header("Location:".base_url()."login");
}?>