       <?php 
              $login = $this->session->userdata("login");
               if(isset($login) && $login == "OK"){

               include("sidebar.php"); ?>



   <!-- explore -->
               <section>
                     <div class="container">
                           <div class="row">
                                <div class="col-md-12">
                                   <ul class="nav nav-tabs" role="tablist" id="nav-tal">
                                     <li class="nav-item">
                                       <a class="nav-link active2 text-t" data-toggle="tab" href="#home"><b> Active Hires</b></a>
                                     </li>
                                     <li class="nav-item">
                                       <a class="nav-link text" data-toggle="tab" href="#menu1"><b>Pending Hires</b></a>
                                     </li>
                                     <li class="nav-item">
                                       <a class="nav-link text" data-toggle="tab" href="#menu2"><b>Hires History</b></a>
                                     </li>
                                   </ul>
                                </div>
                             </div>
                             <div class="row mt-5">
                                <div class="col-md-8">
                                   
                                </div>
                                <div class="col-md-3 search33">
                                   <input type="text" name="search" placeholder="Search here" class="search3"><i class="fa fa-search float-right"></i>
                                </div>
                             </div>
                             <div class="row mt-5">
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-1.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-2.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-3.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                             </div>
                             <div class="row mt-5">
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-4.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                   <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-5.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="card" style="width: 100%;">
                                      <img class="card-img-top w-100" src="<?=base_url();?>assets/images/order-image-6.png" alt="Card image cap">
                                      <div class="card-body">
                                        <h5 class="card-title card-title-2">Order 2234</h5>
                                         <div class="row mt-3">
                                             <div class="col-md-6">
                                                <h6 class="emeta">5 Items</h6>
                                             </div>
                                             <div class="col-md-6">
                                                <h6 class="emeta">Pending Delivery</h6>
                                             </div>
                                           </div>
                                        <a href="#" class="btn btn-primary mt-5 c-title-btn">View Order</a>
                                      </div>
                                    </div>
                                </div>
                             </div>
                          </div>
                        </div>
                        
               </section>
          <!-- explore --><?php 
               }else{
   header("Location:".base_url()."login");
}?>               