<!-- Bootstrap Core CSS -->



<!-- Custom CSS -->



<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/chat.css?v=<?= av() ?>" rel="stylesheet">



<link rel="stylesheet" href="<?php echo base_url(); ?>assets/plugins/font-awesome/css/font-awesome.min.css">



