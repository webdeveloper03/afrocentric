<div class="container">
	<div class="row">
		<div class="col-lg-12">
			<h1><?= __('store.privacy_policy') ?></h1>
			<?php echo $store_setting['policy_content'] ?>
			<div class="clearfix"></div>
			
			<br>
		</div>
	</div>
</div>