    </div>
    </main>
    <!--Footer Area-->

    <footer class="footer bg-dark text-white">
        <div class="container-custom">
            <div class="row align-items-center">
                <div class="col-sm-3">
                    <a class="text-warning" href="javascript:void(0)">
                        <h6 class="mt-2">Privacy Policy</h6>
                    </a>
                </div>
                <div class="col-sm-6"> 
                    <h6 class="mt-2 text-center">
                        <i class="mdi mdi-copyright"></i> Afrocentric Kulture <?= date('Y') ?>
                    </h6>
                </div>
                <div class="col-sm-3">
                    <h6 class="mt-2 text-center">
                        <i class="mdi mdi-facebook"></i>
                        <i class="mdi mdi-instagram"></i>
                    </h6>
                </div>
            </div>
        </div>
    </footer><!--Footer Area-->

    <!-- Owl Carousel Js-->
    <script src="<?= base_url('assets/login/multiple_pages') ?>/js/owl.carousel.min.js"></script>
    <script src="<?= base_url('assets/login/multiple_pages') ?>/js/jquery.mousewheel.min.js"></script>

    <!--Active Js-->
    <script src="<?= base_url('assets/login/multiple_pages') ?>/js/active.js"></script>  

</body>
</html>