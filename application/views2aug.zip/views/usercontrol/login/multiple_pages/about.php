<?php include(APPPATH.'/views/usercontrol/login/multiple_pages/header.php'); ?>

<div class="jumbotron jumbotron-fluid before-nav-spacer">
  <div class="container section-title">
    <h2>About Us</h2>
    <p>This is a modified jumbotron that occupies the entire horizontal space of its parent.</p>
  </div>
</div>

<div class="container py-5">
   <?= $setting['about_content'] ?>
</div>
<?php include(APPPATH.'/views/usercontrol/login/multiple_pages/footer.php'); ?>
