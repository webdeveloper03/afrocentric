<!-- ========== Left Sidebar Start ========== -->
         <div class="left side-menu">
            <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 457px;">
               <div class="sidebar-inner slimscrollleft" style="overflow: hidden; width: auto; height: 457px;">
                  <div id="sidebar-menu" class="active">
                     <!-- <center class="active"><img style="max-width: 125px;margin-top:10px;" src="<?=base_url();?>assets/images/site/Dei4vQVCMyr5fAszw38PRamGjH7ISl9O.png" id="logo" class="img-fluid"></center> -->
                     <ul>
                        <li class="active">
                           <a href="http://localhost/afrocentric/usercontrol/dashboard" class="waves-effect active">
                           <i class="mdi mdi-view-dashboard"></i>
                           <span> Dashboard</span>
                           </a>
                        </li>
                        <li><a href="<?=base_url();?>designer/explore"><i class="mdi mdi-archive"></i>Explore</a></li>
                        <li><a href="Hire-Title2.html"><i class="mdi mdi-cart-outline"></i>Hires</a></li>
                        <li><a href="order.html"><i class="mdi mdi-trending-up"></i>Orders</a></li>
                        <li><a href="products.html" class="waves-effect"><i class="mdi mdi-view-dashboard"></i><span> Products</span></a></li>
                        <li><a href="http://localhost/afrocentric/ReportController/user_reports" class="waves-effect"><i class="mdi mdi-account-settings-variant"></i><span> Commuinty</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>Blogs</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>My Profile</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>My Appointments</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>Measurement Book</span></a></li>
                        <li><a href="accounting.html"><i class="mdi mdi-store"></i> <span>Accounting Book</span></a></li>
                        <li><a href="My-Escrow.html"><i class="mdi mdi-store"></i> <span>Escrow</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>Training</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>About Us</span></a></li>
                        <li><a href="http://localhost/afrocentric/usercontrol/contact-us"><i class="mdi mdi-store"></i> <span>Contact Us</span></a></li>
                        <!-- <li class="has_sub">
                           <a href="javascript:void(0);" class="waves-effect"><i class="mdi mdi-wallet"></i> <span> Subscription Plan </span> <span class="float-right"><i class="mdi mdi-chevron-right"></i></span></a>
                           <ul class="list-unstyled">
                              <li><a href="http://localhost/afrocentric/usercontrol/purchase_plan/">Buy Membership Plans</a></li>
                              <li><a href="http://localhost/afrocentric/usercontrol/purchase_history/">Plan History</a></li>
                           </ul>
                        </li> -->
                     </ul>
                  </div>
                  <div class="clearfix"></div>
               </div>
               <div class="slimScrollBar" style="background: rgb(158, 165, 171); width: 10px; position: absolute; top: 0px; opacity: 0.4; display: block; border-radius: 7px; z-index: 99; right: 1px; height: 416.034px;"></div>
               <div class="slimScrollRail" style="width: 10px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51); opacity: 0.2; z-index: 90; right: 1px;"></div>
            </div>
         </div>
         <!-- Start right Content here -->
         <div class="content-page">
            <!-- Start content -->
            <div class="content">
               <!-- ==================
                  PAGE CONTENT START
                  ================== -->
               <div class="page-content-wrapper">
                  <div class="container-fluid">
                     <script type="text/javascript">console.log('Page ID : usercontrol_dashboard')</script>
                     <div class="row">
                        <div class="col-sm-12">
                           <div class="page-title-box shadow-sm">
                              <div class="float-right">
                                 <ol class="breadcrumb hide-phone p-0 m-0">
                                 </ol>
                              </div>
                              <div class="iconify float-left">
                                 <a class="btn btn-primary btn-sm reload-btn" title="" data-toggle="tooltip" href="JavaScript: location.reload(true);" data-original-title="Refresh Page"><i class="mdi mdi-refresh" data-inline="false" style="font-size: 1.1rem"></i></a>
                              </div>
                              <h4 class="page-title">Welcome: Designer</h4>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br />
               
               <!-- Top Bar Start -->
               <div class="topbar">
                  <!-- LOGO -->
                  <div class="topbar-left">
                     <div class="logo-container">
                     	<center class="active"><img style="max-width: 125px;margin-top:10px;" src="<?=base_url();?>assets/images/site/Dei4vQVCMyr5fAszw38PRamGjH7ISl9O.png" id="logo" class="img-fluid"></center>
                        <!-- <a href="http://localhost/afrocentric/usercontrol/dashboard" class="logo text-center">AFFILIATE PANEL</a> -->
                     </div>
                  </div>
                  <!--<div class="topbar">-->
                  <nav class="navbar-custom">
                     <ul class="list-inline mr-5 float-right mb-0 mt-3"><!-- 
                     	<li class="list-inline-item dropdown notification-list language">
                           
                        </li> -->
                        <!-- language-->
                        <!-- <li class="list-inline-item dropdown notification-list language">
                           <a class="nav-link dropdown-toggle arrow-none waves-effect text-white" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                           <span class="d-none d-sm-inline-block">English</span> <img src="<?=base_url();?>assets/vertical/assets/images/flags/lr.png" class="ml-2" height="16" alt="">
                           </a>
                           <div class="dropdown-menu dropdown-menu-right language-switch"><a class="dropdown-item" href="http://localhost/afrocentric/usercontrol/change_language/3"><img src="<?=base_url();?>assets/vertical/assets/images/flags/in.png" alt="" height="16"><span> Hindi </span></a></div>
                        </li>
 -->                        <li class="list-inline-item dropdown notification-list currency">
                           <!--a class="nav-link dropdown-toggle arrow-none waves-effect text-white" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">₦ <span class="d-none d-sm-inline-block">Nigerian Naira</span> </a-->
                           <div class="dropdown-menu dropdown-menu-right currency-switch"><a class="dropdown-item" href="http://localhost/afrocentric/usercontrol/change_currency/USD"><span> $ US Dollar  </span></a></div>
                        </li>
                        <!-- <li class="list-inline-item dropdown notification-list order-noti">
                           <a class="nav-link text-white" href="http://localhost/afrocentric/usercontrol/mywallet" role="button" data-toggle="tooltip" data-original-title="Hold Orders">
                           	<i class="ti-bell noti-icon"></i>
                           	<span class="badge badge-danger noti-icon-badge">0</span>				
                           </a>
                           </li> -->
                        <li class="list-inline-item dropdown notification-list alert-icon">
                           <a class="nav-link dropdown-toggle arrow-none waves-effect" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                           <i class="fas fa-comment-dots text-white"></i>
                           <span class="badge badge-success noti-icon-badge userside" id="notynew">6</span>
                           </a>
                           <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-menu-lg">
                              <div class="dropdown-item noti-title">
                                 <h5><span class="badge badge-danger float-right" id="notyall">6</span>Notification</h5>
                              </div>
                              <div id="allnotification">
                                 <a href="javascript:void(0)" onclick="shownofication(69,'http://localhost/afrocentric/usercontrol/listproduct/8')" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
                                    <p class="notify-details"><b>New Product Added in Affiliate Program</b><small class="text-muted">Antenatal Program product is addded by admin in affiliate Program on 2021-02-08 20:11:08</small></p>
                                 </a>
                                 <a href="javascript:void(0)" onclick="shownofication(53,'http://localhost/afrocentric/usercontrol/listproduct/6')" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
                                    <p class="notify-details"><b>New Product Added in Affiliate Program</b><small class="text-muted">POSIM - Mega Partner Banquest product is addded by admin in affiliate Program on 2020-11-09 06:05:36</small></p>
                                 </a>
                                 <a href="javascript:void(0)" onclick="shownofication(14,'http://localhost/afrocentric/usercontrol/listproduct/4')" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
                                    <p class="notify-details"><b>New Product Added in Affiliate Program</b><small class="text-muted">Bulk sms unit product is addded by admin in affiliate Program on 2020-03-16 06:54:44</small></p>
                                 </a>
                                 <a href="javascript:void(0)" onclick="shownofication(6,'http://localhost/afrocentric/usercontrol/listproduct/3')" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
                                    <p class="notify-details"><b>New Product Added in Affiliate Program</b><small class="text-muted">MYPOS app product is addded by admin in affiliate Program on 2020-03-05 06:54:36</small></p>
                                 </a>
                                 <a href="javascript:void(0)" onclick="shownofication(5,'http://localhost/afrocentric/usercontrol/listproduct/2')" class="dropdown-item notify-item">
                                    <div class="notify-icon bg-primary"><i class="mdi mdi-cart-outline"></i></div>
                                    <p class="notify-details"><b>New Product Added in Affiliate Program</b><small class="text-muted">School management system termly subscription product is addded by admin in affiliate Program on 2020-03-05 06:42:33</small></p>
                                 </a>
                              </div>
                              <a href="http://localhost/afrocentric/usercontrol/notification" class="dropdown-item notify-item">
                              View All					</a>
                           </div>
                        </li>
                        <li class="list-inline-item dropdown notification-list user-menu">
                           <a class="nav-link dropdown-toggle arrow-none waves-effect nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                           <img class="rounded-circle" src="<?=base_url();?>assets/vertical/assets/images/users/avatar-1.jpg" alt="user" width="40"> <i class="fas fa-caret-down text-white"></i>
                           </a>
                           <div class="dropdown-menu dropdown-menu-right profile-dropdown " style="width: 200px">
                              <!-- item-->
                              <a class="dropdown-item" href="#"><i class="mdi mdi-account-circle m-r-5 text-muted"></i> Profile</a>
                              <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5 text-muted"></i> Change Password</a>
                              <a class="dropdown-item" href="#"><i class="mdi mdi-wallet m-r-5 text-muted"></i> My Wallet</a>
                              <div class="dropdown-divider"></div>
                              <a class="dropdown-item" href="<?=base_url();?>/logout"><i class="mdi mdi-logout m-r-5 text-muted"></i> Logout</a>
                           </div>
                        </li>
                     </ul>
                     <ul class="list-inline menu-left mb-0">
                        <li class="float-left">
                        	<form class="my-2 my-lg-0 ml-5">
                           		<i class="fas fa-search"></i>
						      <input class="form-control mr-sm-2" type="search" placeholder="What are you looking for?" aria-label="Search">
						    </form>
                           <!-- <button class="button-menu-mobile open-left waves-light waves-effect">
                           <i class="mdi mdi-menu"></i> -->
                           </button>
                        </li>
                     </ul>
                     <div class="clearfix"></div>
                  </nav>
               </div>
               <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/flag/css/main.min.css">
               <link rel="stylesheet" type="text/css" href="<?=base_url();?>assets/plugins/table/datatables.min.css">
               <script type="text/javascript" src="<?=base_url();?>assets/plugins/table/datatables.min.js"></script>
               <script type="text/javascript" src="<?=base_url();?>assets/plugins/table/dataTables.responsive.min.js"></script>
               <style>
                  .counter{
                  font-size: 1.7vw;
                  font-weight: bold;
                  }
                  .market-tool-card .card-body{
                  height: 280px !important;
                  overflow:auto;
                  }
                  @media(max-width: 1200px){
                  .counter{
                  font-size: 1.3rem;
                  }
                  }
               </style>
         