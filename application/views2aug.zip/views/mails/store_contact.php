
<tr>
  <td align="center" style="padding:20px 23px 0 23px">
    <table width="600" style="background-color:#FFF; margin:0 auto; border-radius:5px; border-collapse:collapse">
      <tbody>
        <tr>
          <td align="center">
            <table width="500" style="margin:0 auto">
              <tbody>
                <tr>
                  <td align="center" style="font-family:'Roboto', Arial !important">
                     <?php echo $body ?>
                  </td>
                </tr>
                
              </tbody>
            </table>
          </td>
        </tr>
        
      </tbody>
    </table>
  </td>
</tr>
      