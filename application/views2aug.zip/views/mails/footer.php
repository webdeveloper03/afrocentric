                        <tr>
                        <td align="center" style="padding: 0px; background-color: #0c2d69;border-bottom-left-radius: 20px !important;border-bottom-right-radius: 20px !important;">
                          <table width="604" style="border-collapse:collapse;background-color:#0C2D69; font-family:'Roboto', Arial !important; border-spacing: 0 !important;border-bottom-left-radius: 20px !important;border-bottom-right-radius: 20px !important;">
                            <tbody>
                              <tr>
                                <td colspan="4" style="vertical-align:middle;background-color: #0C2D69;border-bottom-left-radius: 20px !important;border-bottom-right-radius: 20px !important;">
                                  <table style="background-color:#0C2D69; width:100%; border-bottom-left-radius: 20px !important;border-bottom-right-radius: 20px !important; border-collapse:collapse; border-spacing: 0 !important">
                                    <tbody>
                                      <tr>
                                        <td align="center" style="vertical-align:middle; padding:5px 0; font-family:'Roboto', Arial !important;color: #fff">
                                              <?= $emailsetting['footer'] ?>
                                        </td>
                                      </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                </tbody>
              </table>
            </td>
          </tr>
        </tbody>
      </table>
  </div>
</body>