
      <tr>
        <td align="center" style="padding:20px 23px 0 23px">
          <table width="600" style="background-color:#FFF; margin:0 auto; border-radius:5px; border-collapse:collapse">
            <tbody>
              <tr>
                <td align="center">
                  <table width="500" style="margin:0 auto">
                    <tbody>
                      <tr>
                        <td align="center" style="padding:40px 0 35px 0">
                          <a href="<?= $base_url ?>" target="_blank" style="color:#128ced; text-decoration:none;outline:0;"><img alt="" src="<?= base_url('assets/images/world.png') ?>" style='    width: 288px;' border="0"></a>
                        </td>
                      </tr>
                      
                      <tr>
                        <td align="center" style="font-family:'Roboto', Arial !important">
                          
                           <h2 style="margin:0; font-weight:bold; font-size:40px; color:#444; text-align:center; font-family:'Roboto', Arial !important">Reset Password</h2>
                          
                        </td>
                      </tr>
                      <tr>
                        <td align="center" style="padding:40px 0 35px 0">
                          We got request to reset your password.
                        </td>
                      </tr>
                      <tr>
                        <td align="center" style="padding-bottom:30px">
                          <table style="width:255px; margin:0 auto;">
                            <tbody>
                              <tr>
                                <td width="255" style="background-color:#008AF1; text-align:center; border-radius:5px; vertical-align:middle; padding:13px 0">
                                  <a href="<?= $resetlink ?>" target="_blank" style="outline:0;color:#FFF; text-transform:uppercase; display:block; text-align:center; text-decoration:none; font-weight:bold; font-size:19px;">Click Here</a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                      <tr>
                        <td align="center" style="padding:40px 0 35px 0">
                         If you ignore this message, your password won't be changed.
                         <br>
                         if you didn't request a pasword reset let us know
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </td>
              </tr>
              
            </tbody>
          </table>
        </td>
      </tr>
      